# Guia de Instalação e Uso do Conversor de Texto para Fala com Backend

Este projeto consiste em duas partes:

1. **Frontend**: Interface web para converter texto em fala
2. **Backend**: Servidor intermediário para comunicação segura com o Azure Speech Service

## Requisitos

- Node.js 14+ instalado
- Navegador web moderno (Chrome, Firefox, Edge, Safari)
- Conexão com internet

## Estrutura de Arquivos

```
conversor-completo/
├── index.html
├── style.css
├── script.js
├── azure-speech.js
├── backend/
│   ├── app.js
│   ├── package.json
│   └── node_modules/
```

## Instalação e Execução

### Passo 1: Configurar o Backend

1. Abra um terminal e navegue até a pasta do backend:
   ```
   cd caminho/para/conversor-completo/backend
   ```

2. Instale as dependências:
   ```
   npm install
   ```

3. Inicie o servidor:
   ```
   node app.js
   ```

4. Você verá uma mensagem indicando que o servidor está rodando na porta 3000.

### Passo 2: Acessar o Frontend

1. Abra o arquivo `index.html` em seu navegador
2. Ou hospede os arquivos do frontend em um servidor web

## Como Usar

1. Digite ou cole o texto que deseja converter em áudio
2. Selecione o idioma desejado (Inglês ou Português)
3. Ajuste a velocidade de fala usando o controle deslizante
4. Clique em "Reproduzir" para ouvir o áudio no navegador
5. Clique em "Download" para baixar o arquivo MP3

## Solução de Problemas

- **Erro de conexão com o backend**: Verifique se o servidor backend está rodando na porta 3000
- **Erro na API do Azure**: Verifique se a chave e região do Azure estão corretas no arquivo `backend/app.js`
- **Problemas de CORS**: O backend já está configurado para permitir requisições de qualquer origem

## Notas Técnicas

- O backend atua como intermediário para proteger a chave do Azure e evitar problemas de CORS
- A chave do Azure está configurada diretamente no backend para maior segurança
- O frontend se comunica com o backend via API REST
- O áudio é gerado no formato MP3 de alta qualidade
